using UnityEngine;
using UnityEngine.Tilemaps;

public enum Tetromino
{
	I, 
	O, 
	T,
	J,
	L,
	S, 
	Z,
}

[System.Serializable]
public struct TetrominoData
{
	public Tetromino tetromino;
	public Tile tile;
	//use the line below if you want to define custom shapes in the editor, not all need to be size 4. At that point you would not initialize
	//public Vector2Int[] cells;
	public Vector2Int[] cells{ get; private set; }
	public Vector2Int[,] wallKicks { get; private set; }

	public void Initialize() 
	{
		this.cells = Data.Cells[this.tetromino];
		this.wallKicks = Data.WallKicks[this.tetromino];
	}
}	




